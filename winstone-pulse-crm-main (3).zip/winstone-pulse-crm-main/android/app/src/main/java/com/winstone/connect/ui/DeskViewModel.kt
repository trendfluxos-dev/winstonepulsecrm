package com.winstone.connect.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.winstone.connect.data.AgentSession
import com.winstone.connect.data.DeskData
import com.winstone.connect.data.parseCalls
import com.winstone.connect.data.parseLeads
import com.winstone.connect.data.parseMessages
import com.winstone.connect.data.remote.WinstoneAgentApi
import com.winstone.connect.data.remote.WinstoneApi
import com.winstone.connect.data.sync.CallSyncQueue
import com.winstone.connect.data.sync.SyncStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class DeskUiState(
    val employeeId: String? = null,
    val agentName: String? = null,
    val loading: Boolean = false,
    val data: DeskData? = null,
    val error: String? = null,
    val toast: String? = null,
    val coach: WinstoneAgentApi.Coach? = null,
    val coachLoading: Boolean = false,
    /** Local time of the last successful CRM sync, for the status screen. */
    val lastSyncedAt: String? = null,
    /** Items still waiting on this phone / given up on, plus the last error. */
    val sync: SyncStatus.Snapshot = SyncStatus.Snapshot(),
    /** Set when the CRM refused this phone (device access removed by IT). */
    val deviceRevoked: Boolean = false,
    /** Honest recording capability of this phone, as reported to the CRM. */
    val recordingStatus: String? = null,
    /** two_sided / mic_only / unavailable — drives the per-lead recording badge. */
    val recordingMode: String? = null,
    /** Technical reason behind the verdict, shown when recording is blocked. */
    val recordingReason: String? = null,
)

class DeskViewModel(private val app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(DeskUiState(employeeId = AgentSession.employeeId))
    val state: StateFlow<DeskUiState> = _state

    init {
        viewModelScope.launch {
            AgentSession.load(app)
            SyncStatus.load(app)
            _state.value = _state.value.copy(employeeId = AgentSession.employeeId)
            if (AgentSession.isSignedIn()) {
                refresh()
                reportRecordingCapability()
            }
            while (true) {
                delay(20_000)
                if (AgentSession.isSignedIn()) {
                    refresh(silent = true)
                    reportRecordingCapability()
                }
            }
        }
        // Live pending / failed / last-error counters for the status screen.
        viewModelScope.launch {
            SyncStatus.state.collect { snap -> _state.value = _state.value.copy(sync = snap) }
        }
    }

    fun signIn(employeeIdOrPhone: String, password: String) {
        val trimmed = employeeIdOrPhone.trim()
        if (trimmed.length < 4 || password.length < 6) {
            _state.value = _state.value.copy(error = "সঠিক Employee ID/ফোন ও পাসওয়ার্ড দিন")
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            runCatching { WinstoneAgentApi.signIn(trimmed, password) }
                .onSuccess { me ->
                    AgentSession.saveDevice(app, me.deviceToken, me.deviceId)
                    AgentSession.saveEmployeeId(app, me.employeeId)
                    // SIM is only sent when the identifier is a phone number.
                    val digitsOnly = trimmed.filter { it.isDigit() }
                    if (digitsOnly.length >= 10) AgentSession.saveSim(app, trimmed)
                    AgentSession.cacheAgent(app, me.agentId, me.name)
                    AgentSession.saveAllowedRoles(app, me.allowedRoles)
                    // Single-desk accounts (every sales agent) skip the role
                    // chooser entirely and land straight on their own desk.
                    if (me.allowedRoles.size == 1) {
                        AgentSession.saveSelectedRole(app, me.allowedRoles.first())
                    } else {
                        AgentSession.saveSelectedRole(app, "")
                    }
                    _state.value = _state.value.copy(
                        employeeId = me.employeeId,
                        agentName = me.name,
                        error = null,
                    )
                    refresh()
                }
                .onFailure { e ->
                    _state.value = _state.value.copy(
                        loading = false,
                        error = e.message ?: "সাইন ইন করা যায়নি",
                    )
                }
        }
    }

    /**
     * Probes this phone's recorder and posts the honest verdict to the CRM.
     * Re-probes at most every 10 minutes, and only reports when the verdict
     * changed or the last report is older than 10 minutes — so IT always sees a
     * live state without hammering the server.
     */
    private var lastCapability: String? = null
    private var lastCapabilityAt = 0L

    private suspend fun reportRecordingCapability() {
        val staleMs = 10 * 60_000L
        val stale = System.currentTimeMillis() - lastCapabilityAt > staleMs
        val capability = com.winstone.connect.telephony.RecordingCapabilityCheck
            .check(app, force = stale)
        val mode = when (capability.support) {
            com.winstone.connect.telephony.RecordingSupport.TWO_SIDED -> "two_sided"
            com.winstone.connect.telephony.RecordingSupport.AGENT_SIDE_ONLY -> "mic_only"
            com.winstone.connect.telephony.RecordingSupport.UNAVAILABLE -> "unavailable"
        }
        // The lead list must show the real verdict even when the CRM is offline,
        // so the local state is updated before the report is attempted.
        _state.value = _state.value.copy(
            recordingMode = mode,
            recordingReason = capability.reason,
        )
        if (mode == lastCapability && !stale) return
        runCatching {
            WinstoneAgentApi.reportRecordingCapability(
                mode,
                capability.reason,
                AgentSession.simNumberNow(app),
            )
        }
            .onSuccess {
                lastCapability = mode
                lastCapabilityAt = System.currentTimeMillis()
                _state.value = _state.value.copy(recordingStatus = capability.label)
            }
    }

    /** Lets the agent re-check recording support by hand from the status screen. */
    fun recheckRecording() {
        viewModelScope.launch {
            lastCapabilityAt = 0L
            reportRecordingCapability()
        }
    }

    fun signOut() {
        viewModelScope.launch {
            // Revoke ONLY this phone's token on the server, then wipe local state.
            // Offline sign-out still clears locally; the token stays revocable from IT Console.
            AgentSession.deviceTokenNow(app)?.let { WinstoneApi.logout(it) }
            AgentSession.clear(app)
            _state.value = DeskUiState()
        }
    }

    fun refresh(silent: Boolean = false) {
        val employeeId = AgentSession.employeeId ?: return
        viewModelScope.launch {
            if (!silent) _state.value = _state.value.copy(loading = true, error = null)
            runCatching { WinstoneApi.fetchWorkspace(employeeId) }
                .onSuccess { ws ->
                    AgentSession.cacheAgent(app, ws.agentId, ws.agentName)
                    _state.value = _state.value.copy(
                        loading = false,
                        error = null,
                        lastSyncedAt = java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.getDefault())
                            .format(java.util.Date()),
                        data = DeskData(
                            agentId = ws.agentId,
                            agentName = ws.agentName,
                            leads = parseLeads(ws.leads),
                            calls = parseCalls(ws.calls),
                            messages = parseMessages(ws.whatsapp),
                        ),
                    )
                }
                .onFailure { e ->
                    val message = e.message.orEmpty()
                    // IT removed this phone's access: stop using the stored token
                    // and send the agent back to sign-in with a clear reason.
                    val revoked = message.contains("Unauthorized", ignoreCase = true) ||
                        message.contains("device", ignoreCase = true) && message.contains("revoke", ignoreCase = true)
                    if (revoked) {
                        AgentSession.clear(app)
                        _state.value = DeskUiState(
                            deviceRevoked = true,
                            error = "এই ফোনের অনুমতি বাতিল করা হয়েছে — আবার সাইন ইন করুন",
                        )
                    } else {
                        _state.value = _state.value.copy(
                            loading = false,
                            error = message.ifBlank { "সার্ভারে সংযোগ করা যাচ্ছে না" },
                        )
                    }
                }
        }
    }

    fun loadCoach() {
        val employeeId = AgentSession.employeeId ?: return
        viewModelScope.launch {
            _state.value = _state.value.copy(coachLoading = true)
            runCatching { WinstoneAgentApi.fetchCoach(employeeId) }
                .onSuccess { _state.value = _state.value.copy(coachLoading = false, coach = it) }
                .onFailure {
                    _state.value = _state.value.copy(
                        coachLoading = false,
                        toast = it.message ?: "AI কোচ আনা যায়নি",
                    )
                }
        }
    }

    fun submitLead(name: String, phone: String, company: String, notes: String) {
        val clientRef = java.util.UUID.randomUUID().toString()
        val payload = WinstoneAgentApi.leadPayload(
            name = name,
            phone = phone,
            company = company,
            notes = notes,
            agentId = AgentSession.agentId,
            clientRef = clientRef,
        )
        viewModelScope.launch {
            runCatching { WinstoneAgentApi.submitLeadRaw(payload) }
                .onSuccess {
                    _state.value = _state.value.copy(toast = "লিড জমা হয়েছে")
                    refresh(silent = true)
                }
                .onFailure { error ->
                    val message = error.message.orEmpty()
                    val badPayload = message.contains("Invalid") || message.contains("Unauthorized")
                    if (badPayload) {
                        _state.value = _state.value.copy(toast = message.ifBlank { "লিড জমা হয়নি" })
                    } else {
                        // No signal: park the lead on the phone and send it once
                        // the connection is back — nothing typed is ever lost.
                        payload.put("captured_offline", true)
                        CallSyncQueue.queueLeadSubmit(getApplication(), clientRef, payload.toString())
                        _state.value = _state.value.copy(
                            toast = "ইন্টারনেট নেই — লিড ফোনে সংরক্ষিত, সংযোগ ফিরলে নিজে থেকেই পাঠানো হবে",
                        )
                    }
                }
        }
    }

    /**
     * Opens WhatsApp on the agent's own phone with the typed message, then syncs
     * that message to the CRM so it appears on the lead timeline. The message is
     * only recorded as sent from this phone — nothing is marked delivered, since
     * WhatsApp never reports delivery back to us.
     */
    fun sendWhatsApp(leadId: String, phone: String, text: String) {
        val body = text.trim()
        if (body.isBlank()) return
        val digits = phone.filter { it.isDigit() }
        val waNumber = when {
            digits.startsWith("880") -> digits
            digits.startsWith("0") -> "880" + digits.drop(1)
            else -> digits
        }
        val opened = runCatching {
            val intent = android.content.Intent(
                android.content.Intent.ACTION_VIEW,
                android.net.Uri.parse(
                    "https://wa.me/$waNumber?text=" + java.net.URLEncoder.encode(body, "UTF-8"),
                ),
            ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            app.startActivity(intent)
        }.isSuccess
        if (!opened) {
            _state.value = _state.value.copy(toast = "এই ফোনে হোয়াটসঅ্যাপ খোলা যায়নি")
            return
        }
        viewModelScope.launch {
            val clientMessageId = "wa-" + java.util.UUID.randomUUID().toString()
            runCatching { WinstoneAgentApi.syncWhatsApp(leadId, clientMessageId, body) }
                .onSuccess {
                    _state.value = _state.value.copy(toast = "হোয়াটসঅ্যাপ মেসেজ CRM-এ জমা হয়েছে")
                    refresh(silent = true)
                }
                .onFailure {
                    _state.value = _state.value.copy(
                        toast = it.message ?: "মেসেজ CRM-এ জমা হয়নি — আবার চেষ্টা করুন",
                    )
                }
        }
    }

    fun clearToast() {
        _state.value = _state.value.copy(toast = null)
    }
}
