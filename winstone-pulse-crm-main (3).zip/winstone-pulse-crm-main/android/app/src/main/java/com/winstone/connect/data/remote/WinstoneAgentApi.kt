package com.winstone.connect.data.remote

import com.winstone.connect.data.AgentSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * The two calls the desk screen needs on top of WinstoneApi:
 * submitting a lead the agent found themselves, and pulling the AI Copilot
 * briefing the web CRM shows on /coach.
 */
object WinstoneAgentApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    data class AgentIdentity(
        val employeeId: String,
        val agentId: String,
        val name: String,
        val phone: String?,
        val deviceToken: String,
        val deviceId: String,
        /** Desks this role may open: agent | coordinator | executive | it_console. */
        val allowedRoles: List<String>,
    )

    /** CRM credentials sign-in: phone number + password, exactly like the web desk. */
    suspend fun signIn(phone: String, password: String): AgentIdentity = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("email", phone.trim())
            put("password", password)
            put("device_label", android.os.Build.MODEL)
            // The agent signs in with their own SIM number, so the CRM can bind
            // that SIM to this desk and never sync a SIM call to another agent.
            val simDigits = phone.filter { it.isDigit() }
            if (simDigits.length >= 10) put("sim_number", phone.trim())
        }
        val req = Request.Builder()
            .url(WinstoneApi.BASE_URL + "/api/public/agent/login")
            .post(payload.toString().toRequestBody(JSON))
            .build()
        client.newCall(req).execute().use { res ->
            val body = runCatching { JSONObject(res.body?.string().orEmpty()) }.getOrElse { JSONObject() }
            if (!res.isSuccessful) {
                val reason = body.optString("error", "সাইন ইন করা যায়নি (HTTP ${res.code})")
                val recovery = body.optString("recovery")
                error(if (recovery.isNotBlank()) "$reason — $recovery" else reason)
            }
            val agent = body.optJSONObject("agent") ?: error("সাইন ইন করা যায়নি")
            val token = body.optString("device_token")
            if (token.isBlank()) error("ডিভাইস অনুমোদন পাওয়া যায়নি")
            AgentIdentity(
                employeeId = agent.optString("employee_id"),
                agentId = agent.optString("id"),
                name = agent.optString("name"),
                phone = agent.optString("phone").takeIf { it.isNotBlank() && it != "null" },
                deviceToken = token,
                deviceId = body.optString("device_id"),
                allowedRoles = agent.optJSONArray("allowed_roles")?.let { arr ->
                    (0 until arr.length()).mapNotNull { arr.optString(it).takeIf(String::isNotBlank) }
                }.orEmpty().ifEmpty { listOf("agent") },
            )
        }
    }

    data class Coach(
        val summary: String,
        val strengths: List<String>,
        val risks: List<String>,
        val nextSteps: List<String>,
    )

    suspend fun submitLead(
        name: String,
        phone: String,
        company: String?,
        notes: String?,
        agentId: String?,
    ): JSONObject = submitLeadRaw(leadPayload(name, phone, company, notes, agentId))

    /**
     * The exact lead payload, so a lead typed with no signal can be parked in
     * the sync queue and replayed once the connection is back. `client_ref`
     * makes the replay idempotent, and the version stamp lets the CRM hand the
     * lead back if this phone moves to a newer app version.
     */
    fun leadPayload(
        name: String,
        phone: String,
        company: String?,
        notes: String?,
        agentId: String?,
        clientRef: String = java.util.UUID.randomUUID().toString(),
        capturedOffline: Boolean = false,
    ): JSONObject = JSONObject().apply {
        put("name", name)
        put("phone_number", phone)
        if (!company.isNullOrBlank()) put("company", company)
        if (!notes.isNullOrBlank()) put("notes", notes)
        put("source", "agent_app")
        // Phone captures land unassigned; LeadHub Nexus routes them. The server
        // attributes the capture to this agent from the device token.
        put("client_ref", clientRef)
        put("captured_offline", capturedOffline)
        put("captured_at", com.winstone.connect.data.IsoTime.now())
        com.winstone.connect.data.AppVersion.name?.let { put("app_version", it) }
        com.winstone.connect.data.AppVersion.code.takeIf { it > 0 }?.let { put("version_code", it) }
    }

    /** Sends a lead payload (fresh or replayed from the offline queue). */
    suspend fun submitLeadRaw(payload: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(WinstoneApi.BASE_URL + "/api/public/ingest/lead")
            .header("x-device-token", AgentSession.deviceToken.orEmpty())
            .post(payload.toString().toRequestBody(JSON))
            .build()
        client.newCall(req).execute().use { res ->
            val body = runCatching { JSONObject(res.body?.string().orEmpty()) }.getOrElse { JSONObject() }
            if (!res.isSuccessful) error(body.optString("error", "HTTP ${res.code}"))
            body
        }
    }

    suspend fun fetchCoach(employeeId: String): Coach = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("${WinstoneApi.BASE_URL}/api/public/agent/coach?employee_id=$employeeId")
            .header("x-device-token", AgentSession.deviceToken.orEmpty())
            .get()
            .build()
        client.newCall(req).execute().use { res ->
            val body = runCatching { JSONObject(res.body?.string().orEmpty()) }.getOrElse { JSONObject() }
            if (!res.isSuccessful) error(body.optString("error", "HTTP ${res.code}"))
            val brief = body.optJSONObject("briefing") ?: body.optJSONObject("coach") ?: body
            Coach(
                summary = brief.optString("summary").ifBlank { "এখনও পর্যাপ্ত কল ডেটা নেই।" },
                strengths = brief.stringList("strengths"),
                risks = brief.stringList("risks"),
                nextSteps = brief.stringList("next_steps", "nextSteps"),
            )
        }
    }

    /**
     * Reports this phone's real recording capability to the CRM, so IT sees the
     * honest state (call audio / microphone only / blocked) in real time.
     */
    suspend fun reportRecordingCapability(
        mode: String,
        note: String?,
        simNumber: String? = null,
    ): Unit = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("recording_mode", mode)
            if (!note.isNullOrBlank()) put("recording_note", note.take(300))
            put("app_version", com.winstone.connect.BuildConfig.VERSION_NAME)
            put("android_version", android.os.Build.VERSION.SDK_INT.toString())
            put("manufacturer", android.os.Build.MANUFACTURER)
            put("model", android.os.Build.MODEL)
            if (!simNumber.isNullOrBlank()) put("sim_number", simNumber.trim())
        }
        val req = Request.Builder()
            .url(WinstoneApi.BASE_URL + "/api/public/agent/device-capability")
            .header("x-device-token", AgentSession.deviceToken.orEmpty())
            .post(payload.toString().toRequestBody(JSON))
            .build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) error("রেকর্ডিং স্ট্যাটাস পাঠানো যায়নি (HTTP ${res.code})")
        }
    }

    /**
     * Syncs a WhatsApp message the agent sent from their own phone to the CRM,
     * so the lead timeline shows the conversation next to the SIM calls.
     * The client message id makes a retry idempotent: the same message never
     * lands twice, exactly like the recording upload path.
     */
    suspend fun syncWhatsApp(
        leadId: String,
        clientMessageId: String,
        text: String,
    ): JSONObject = withContext(Dispatchers.IO) {
        val message = JSONObject().apply {
            put("client_message_id", clientMessageId)
            put("sender", "agent")
            put("message_type", "text")
            put("text", text)
        }
        val payload = JSONObject().apply {
            put("lead_id", leadId)
            put("messages", org.json.JSONArray().put(message))
        }
        val req = Request.Builder()
            .url(WinstoneApi.BASE_URL + "/api/public/agent/whatsapp")
            .header("x-device-token", AgentSession.deviceToken.orEmpty())
            .post(payload.toString().toRequestBody(JSON))
            .build()
        client.newCall(req).execute().use { res ->
            val body = runCatching { JSONObject(res.body?.string().orEmpty()) }.getOrElse { JSONObject() }
            if (!res.isSuccessful) error(body.optString("error", "HTTP ${res.code}"))
            body
        }
    }

    private fun JSONObject.stringList(vararg keys: String): List<String> {
        for (key in keys) {
            val arr = optJSONArray(key) ?: continue
            return (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }
        }
        return emptyList()
    }
}
